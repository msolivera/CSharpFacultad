﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio3
{
    public class Esqueleto :TropaNormal
    {
        public Esqueleto(String nombre, Int32 vida, Int32 lvl, float vel, float dps, Int32 espacio, Int32 costeRojo) : base(nombre, vida, lvl, vel, dps, espacio, costeRojo)
        {

        }
    }
}
