﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio3
{
    public class Barbaro:TropaNormal
    {
        public Barbaro() : base("Barbaro", 78, 1, 20, 18, 1, 25)
        {
              
        }
    }
}
